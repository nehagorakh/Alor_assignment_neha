package com.alor.HM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmApplicationTests {

	@Test
	void contextLoads() {
	}

}
